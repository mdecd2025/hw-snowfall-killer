import math
degree = math.pi/180
print(18*degree)
print(64.56*degree)
print(135.54*degree)